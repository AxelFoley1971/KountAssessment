﻿using System;
using System.Collections.Generic;

namespace Kount_Assessment
{
    class Program
    {
        static Setup setup = new Setup();
        public static Robot robot = setup.SetupRobot(new Robot());
        public static List<Location> locations = setup.SetupLocations();
        
        static void Main(string[] args)
        {
            CommandParser commandParser = new CommandParser();

            string inputCommand;
            string result;

            Console.WriteLine("Robot is in spot 1.");
            Console.WriteLine("Crates are in spot 5 and spot 13.");

            do
            {
                Console.Write(">");
                inputCommand = Console.ReadLine();
                result = commandParser.RunCommand(inputCommand);
                
                Console.WriteLine(result);

            } while (inputCommand != "q");
        }
    }
}
