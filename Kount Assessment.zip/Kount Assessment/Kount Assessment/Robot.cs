﻿
namespace Kount_Assessment
{
    public class Robot
    {
        private int location;
        private bool hasBox;

        public int Location
        {
            get { return location; }
            set { location = value; }
        }

        public bool HasBox
        {
            get { return hasBox; }
            set { hasBox = value; }
        }

        public string MoveRobot(string direction, Robot robot)
        {
            Location curLocation = FindLocationInList(robot.location);
            string result = string.Empty;

            switch (direction)
            {
                case "n":
                    if (curLocation.MoveNorth != 0)
                    {
                        robot.location = curLocation.MoveNorth;

                        result = $"Robot moved north to spot {curLocation.MoveNorth}.";
                    }
                    else
                    {
                        result = "Cannot move north from here.";
                    }

                    break;
                case "s":
                    if (curLocation.MoveSouth != 0)
                    {
                        robot.location = curLocation.MoveSouth;

                        result = $"Robot moved south to spot {curLocation.MoveSouth}.";
                    }
                    else
                    {
                        result = "Cannot move south from here.";
                    }

                    break;
                case "e":
                    if (curLocation.MoveEast != 0)
                    {
                        robot.location = curLocation.MoveEast;

                        result = $"Robot moved east to spot {curLocation.MoveEast}.";
                    }
                    else
                    {
                        result = "Cannot move east from here.";
                    }
                    break;
                case "w":
                    if (curLocation.MoveWest != 0)
                    {
                        robot.location = curLocation.MoveWest;

                        result = $"Robot moved west to spot {curLocation.MoveWest}.";
                    }
                    else
                    {
                        result = "Cannot move west from here.";
                    }
                    break;
                case "nw":
                    if (curLocation.MoveNorthWest != 0)
                    {
                        robot.location = curLocation.MoveNorthWest;

                        result = $"Robot moved northwest to spot {curLocation.MoveNorthWest}.";
                    }
                    else
                    {
                        result = "Cannot move northwest from here.";
                    }
                    break;
                case "ne":
                    if (curLocation.MoveNorthEast != 0)
                    {
                        robot.location = curLocation.MoveNorthEast;

                        result = $"Robot moved northeast to spot {curLocation.MoveEast}.";
                    }
                    else
                    {
                        result = "Cannot move northeast from here.";
                    }
                    break;
                case "sw":
                    if (curLocation.MoveSouthWest != 0)
                    {
                        robot.location = curLocation.MoveSouthWest;

                        result = $"Robot moved southwest to spot {curLocation.MoveSouthWest}.";
                    }
                    else
                    {
                        result = "Cannot move southwest from here.";
                    }
                    break;
                case "se":
                    if (curLocation.MoveSouthEast != 0)
                    {
                        robot.location = curLocation.MoveSouthEast;

                        result = $"Robot moved southeast to spot {curLocation.MoveSouthEast}.";
                    }
                    else
                    {
                        result = "Cannot move southeast from here.";
                    }
                    break;
                default:
                    result = $"{direction} is an invalid direction command.";

                    break;
            }

            result += ReportCrate(robot.location);

            return result;
        }

        public string GrabBox(Robot robot)
        {
            Location curLocation = FindLocationInList(robot.location);
            string result = string.Empty;

            if (!robot.HasBox)
            {
                if (curLocation.HasBox)
                {
                    robot.HasBox = true;
                    RemoveCrateFromLocation(robot.location);

                    result = $"Robot picked up a crate from spot {robot.location}.";
                }
                else
                {
                    result = "This location does not have a crate.";
                }
            }
            else
            {
                result = "Robot already has a crate.";
            }

            return result;
        }

        public string DropBox(Robot robot)
        {
            Location curLocation = FindLocationInList(robot.location);
            string result = string.Empty;

            if (robot.HasBox)
            {
                if (!curLocation.HasBox)
                {
                    robot.HasBox = false;
                    AddCrateToLocation(robot.location);

                    result = $"Robot dropped crate on spot {robot.location}.";
                }
                else
                {
                    result = "There is already a crate in this spot.";
                }
            }
            else
            {
                result = "Robot does not have a crate.";
            }

            return result;
        }

        private Location FindLocationInList(int locationNumber)
        {
            foreach(Location curLocation in Program.locations)
            {
                if (curLocation.LocationNumber == locationNumber)
                {
                    return curLocation;
                }
            }

            return new Location();
        }

        private void RemoveCrateFromLocation(int locationNumber)
        {
            foreach (Location curLocation in Program.locations)
            {
                if (curLocation.LocationNumber == locationNumber)
                {
                    curLocation.HasBox = false;
                }
            }
        }

        private void AddCrateToLocation(int locationNumber)
        {
            foreach (Location curLocation in Program.locations)
            {
                if (curLocation.LocationNumber == locationNumber)
                {
                    curLocation.HasBox = true;
                }
            }
        }

        private string ReportCrate(int location)
        {
            Location newLocation = FindLocationInList(location);

            if (newLocation.HasBox)
            {
                return "\r\nThere is a crate here.";
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
