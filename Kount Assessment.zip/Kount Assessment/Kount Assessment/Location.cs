﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kount_Assessment
{
    public class Location
    {
        private int locationNumber;
        private bool hasBox;
        private int moveNorth;
        private int moveSouth;
        private int moveEast;
        private int moveWest;
        private int moveNorthWest;
        private int moveSouthWest;
        private int moveNorthEast;
        private int moveSouthEast;

        public int LocationNumber
        {
            get { return locationNumber; }
            set { locationNumber = value; }
        }

        public bool HasBox
        {
            get { return hasBox; }
            set { hasBox = value; }
        }

        public int MoveNorth
        {
            get { return moveNorth; }
            set { moveNorth = value; }
        }

        public int MoveSouth
        {
            get { return moveSouth; }
            set { moveSouth = value; }
        }

        public int MoveEast
        {
            get { return moveEast; }
            set { moveEast = value; }
        }

        public int MoveWest
        {
            get { return moveWest; }
            set { moveWest = value; }
        }

        public int MoveNorthWest
        {
            get { return moveNorthWest; }
            set { moveNorthWest = value; }
        }

        public int MoveSouthWest
        {
            get { return moveSouthWest; }
            set { moveSouthWest = value; }
        }

        public int MoveNorthEast
        {
            get { return moveNorthEast; }
            set { moveNorthEast = value; }
        }

        public int MoveSouthEast
        {
            get { return moveSouthEast; }
            set { moveSouthEast = value; }
        }
    }
}
