﻿using System.Collections.Generic;
using System.Linq;

namespace Kount_Assessment
{
    public class CommandParser
    {
        public string RunCommand(string input)
        {
            List<string> commands = input.ToLower().Split(' ').ToList();
            string result = string.Empty;

            foreach(string curCommand in commands)
            {
                switch (curCommand)
                {
                    case "n":
                    case "s":
                    case "e":
                    case "w":
                    case "nw":
                    case "ne":
                    case "sw":
                    case "se":
                        result = Program.robot.MoveRobot(curCommand, Program.robot);

                        break;
                    case "g":
                        result = Program.robot.GrabBox(Program.robot);

                        break;
                    case "d":
                        result = Program.robot.DropBox(Program.robot);

                        break;
                    default:
                        result = $"{curCommand} is not a valid command.";

                        break;
                }
            }

            return result;
        }
    }
}
