﻿using System.Collections.Generic;

namespace Kount_Assessment
{
    public class Setup
    {        
        public Robot SetupRobot(Robot robot)
        {
            robot.Location = 1;
            robot.HasBox = false;

            return robot;
        }

        public List<Location> SetupLocations()
        {
            List<Location> locations = new List<Location>();

            Location location1 = new Location();
            location1.LocationNumber = 1;
            location1.HasBox = false;
            location1.MoveNorth = 0;
            location1.MoveSouth = 6;
            location1.MoveEast = 2;
            location1.MoveWest = 0;
            location1.MoveNorthWest = 0;
            location1.MoveSouthWest = 0;
            location1.MoveNorthEast = 0;
            location1.MoveSouthEast = 7;

            locations.Add(location1);

            Location location2 = new Location();
            location2.LocationNumber = 2;
            location2.HasBox = false;
            location2.MoveNorth = 0;
            location2.MoveSouth = 7;
            location2.MoveEast = 3;
            location2.MoveWest = 1;
            location2.MoveNorthWest = 0;
            location2.MoveSouthWest = 6;
            location2.MoveNorthEast = 0;
            location2.MoveSouthEast = 8;

            locations.Add(location2);

            Location location3 = new Location();
            location3.LocationNumber = 3;
            location3.HasBox = false;
            location3.MoveNorth = 0;
            location3.MoveSouth = 8;
            location3.MoveEast = 4;
            location3.MoveWest = 2;
            location3.MoveNorthWest = 0;
            location3.MoveSouthWest = 7;
            location3.MoveNorthEast = 0;
            location3.MoveSouthEast = 9;

            locations.Add(location3);

            Location location4 = new Location();
            location4.LocationNumber = 4;
            location4.HasBox = false;
            location4.MoveNorth = 0;
            location4.MoveSouth = 9;
            location4.MoveEast = 5;
            location4.MoveWest = 3;
            location4.MoveNorthWest = 0;
            location4.MoveSouthWest = 8;
            location4.MoveNorthEast = 0;
            location4.MoveSouthEast = 10;

            locations.Add(location4);

            Location location5 = new Location();
            location5.LocationNumber = 5;
            location5.HasBox = true;
            location5.MoveNorth = 0;
            location5.MoveSouth = 10;
            location5.MoveEast = 0;
            location5.MoveWest = 4;
            location5.MoveNorthWest = 0;
            location5.MoveSouthWest = 9;
            location5.MoveNorthEast = 0;
            location5.MoveSouthEast = 0;

            locations.Add(location5);

            Location location6 = new Location();
            location6.LocationNumber = 6;
            location6.HasBox = false;
            location6.MoveNorth = 1;
            location6.MoveSouth = 11;
            location6.MoveEast = 7;
            location6.MoveWest = 0;
            location6.MoveNorthWest = 0;
            location6.MoveSouthWest = 0;
            location6.MoveNorthEast = 2;
            location6.MoveSouthEast = 12;

            locations.Add(location6);

            Location location7 = new Location();
            location7.LocationNumber = 7;
            location7.HasBox = false;
            location7.MoveNorth = 2;
            location7.MoveSouth = 12;
            location7.MoveEast = 8;
            location7.MoveWest = 6;
            location7.MoveNorthWest = 1;
            location7.MoveSouthWest = 11;
            location7.MoveNorthEast = 3;
            location7.MoveSouthEast = 13;

            locations.Add(location7);

            Location location8 = new Location();
            location8.LocationNumber = 8;
            location8.HasBox = false;
            location8.MoveNorth = 3;
            location8.MoveSouth = 13;
            location8.MoveEast = 9;
            location8.MoveWest = 7;
            location8.MoveNorthWest = 2;
            location8.MoveSouthWest = 12;
            location8.MoveNorthEast = 4;
            location8.MoveSouthEast = 14;

            locations.Add(location8);

            Location location9 = new Location();
            location9.LocationNumber = 9;
            location9.HasBox = false;
            location9.MoveNorth = 4;
            location9.MoveSouth = 14;
            location9.MoveEast = 10;
            location9.MoveWest = 8;
            location9.MoveNorthWest = 3;
            location9.MoveSouthWest = 13;
            location9.MoveNorthEast = 5;
            location9.MoveSouthEast = 15;

            locations.Add(location9);

            Location location10 = new Location();
            location10.LocationNumber = 10;
            location10.HasBox = false;
            location10.MoveNorth = 5;
            location10.MoveSouth = 15;
            location10.MoveEast = 0;
            location10.MoveWest = 9;
            location10.MoveNorthWest = 4;
            location10.MoveSouthWest = 14;
            location10.MoveNorthEast = 0;
            location10.MoveSouthEast = 0;

            locations.Add(location10);

            Location location11 = new Location();
            location11.LocationNumber = 11;
            location11.HasBox = false;
            location11.MoveNorth = 6;
            location11.MoveSouth = 16;
            location11.MoveEast = 12;
            location11.MoveWest = 0;
            location11.MoveNorthWest = 0;
            location11.MoveSouthWest = 0;
            location11.MoveNorthEast = 7;
            location11.MoveSouthEast = 17;

            locations.Add(location11);

            Location location12 = new Location();
            location12.LocationNumber = 12;
            location12.HasBox = false;
            location12.MoveNorth = 7;
            location12.MoveSouth = 17;
            location12.MoveEast = 13;
            location12.MoveWest = 11;
            location12.MoveNorthWest = 6;
            location12.MoveSouthWest = 16;
            location12.MoveNorthEast = 8;
            location12.MoveSouthEast = 18;

            locations.Add(location12);

            Location location13 = new Location();
            location13.LocationNumber = 13;
            location13.HasBox = true;
            location13.MoveNorth = 8;
            location13.MoveSouth = 18;
            location13.MoveEast = 14;
            location13.MoveWest = 12;
            location13.MoveNorthWest = 7;
            location13.MoveSouthWest = 17;
            location13.MoveNorthEast = 9;
            location13.MoveSouthEast = 19;

            locations.Add(location13);

            Location location14 = new Location();
            location14.LocationNumber = 14;
            location14.HasBox = false;
            location14.MoveNorth = 9;
            location14.MoveSouth = 19;
            location14.MoveEast = 15;
            location14.MoveWest = 13;
            location14.MoveNorthWest = 8;
            location14.MoveSouthWest = 20;
            location14.MoveNorthEast = 10;
            location14.MoveSouthEast = 20;

            locations.Add(location14);

            Location location15 = new Location();
            location15.LocationNumber = 15;
            location15.HasBox = false;
            location15.MoveNorth = 10;
            location15.MoveSouth = 20;
            location15.MoveEast = 0;
            location15.MoveWest = 14;
            location15.MoveNorthWest = 9;
            location15.MoveSouthWest = 19;
            location15.MoveNorthEast = 0;
            location15.MoveSouthEast = 0;

            locations.Add(location15);

            Location location16 = new Location();
            location16.LocationNumber = 16;
            location16.HasBox = false;
            location16.MoveNorth = 11;
            location16.MoveSouth = 21;
            location16.MoveEast = 17;
            location16.MoveWest = 0;
            location16.MoveNorthWest = 0;
            location16.MoveSouthWest = 0;
            location16.MoveNorthEast = 12;
            location16.MoveSouthEast = 22;

            locations.Add(location16);

            Location location17 = new Location();
            location17.LocationNumber = 17;
            location17.HasBox = false;
            location17.MoveNorth = 12;
            location17.MoveSouth = 22;
            location17.MoveEast = 18;
            location17.MoveWest = 16;
            location17.MoveNorthWest = 11;
            location17.MoveSouthWest = 21;
            location17.MoveNorthEast = 13;
            location17.MoveSouthEast = 23;

            locations.Add(location17);

            Location location18 = new Location();
            location18.LocationNumber = 18;
            location18.HasBox = false;
            location18.MoveNorth = 13;
            location18.MoveSouth = 23;
            location18.MoveEast = 19;
            location18.MoveWest = 17;
            location18.MoveNorthWest = 12;
            location18.MoveSouthWest = 22;
            location18.MoveNorthEast = 14;
            location18.MoveSouthEast = 24;

            locations.Add(location18);

            Location location19 = new Location();
            location19.LocationNumber = 19;
            location19.HasBox = false;
            location19.MoveNorth = 14;
            location19.MoveSouth = 24;
            location19.MoveEast = 20;
            location19.MoveWest = 18;
            location19.MoveNorthWest = 13;
            location19.MoveSouthWest = 23;
            location19.MoveNorthEast = 15;
            location19.MoveSouthEast = 25;

            locations.Add(location19);

            Location location20 = new Location();
            location20.LocationNumber = 20;
            location20.HasBox = false;
            location20.MoveNorth = 15;
            location20.MoveSouth = 25;
            location20.MoveEast = 0;
            location20.MoveWest = 19;
            location20.MoveNorthWest = 14;
            location20.MoveSouthWest = 24;
            location20.MoveNorthEast = 0;
            location20.MoveSouthEast = 0;

            locations.Add(location20);

            Location location21 = new Location();
            location21.LocationNumber = 21;
            location21.HasBox = false;
            location21.MoveNorth = 16;
            location21.MoveSouth = 0;
            location21.MoveEast = 22;
            location21.MoveWest = 0;
            location21.MoveNorthWest = 0;
            location21.MoveSouthWest = 0;
            location21.MoveNorthEast = 17;
            location21.MoveSouthEast = 0;

            locations.Add(location21);

            Location location22 = new Location();
            location22.LocationNumber = 22;
            location22.HasBox = false;
            location22.MoveNorth = 17;
            location22.MoveSouth = 0;
            location22.MoveEast = 23;
            location22.MoveWest = 21;
            location22.MoveNorthWest = 16;
            location22.MoveSouthWest = 0;
            location22.MoveNorthEast = 18;
            location22.MoveSouthEast = 0;

            locations.Add(location22);

            Location location23 = new Location();
            location23.LocationNumber = 23;
            location23.HasBox = false;
            location23.MoveNorth = 18;
            location23.MoveSouth = 0;
            location23.MoveEast = 24;
            location23.MoveWest = 22;
            location23.MoveNorthWest = 17;
            location23.MoveSouthWest = 0;
            location23.MoveNorthEast = 19;
            location23.MoveSouthEast = 0;

            locations.Add(location23);

            Location location24 = new Location();
            location24.LocationNumber = 24;
            location24.HasBox = false;
            location24.MoveNorth = 19;
            location24.MoveSouth = 0;
            location24.MoveEast = 25;
            location24.MoveWest = 23;
            location24.MoveNorthWest = 18;
            location24.MoveSouthWest = 0;
            location24.MoveNorthEast = 20;
            location24.MoveSouthEast = 0;

            locations.Add(location24);

            Location location25 = new Location();
            location25.LocationNumber = 25;
            location25.HasBox = false;
            location25.MoveNorth = 20;
            location25.MoveSouth = 0;
            location25.MoveEast = 0;
            location25.MoveWest = 24;
            location25.MoveNorthWest = 19;
            location25.MoveSouthWest = 0;
            location25.MoveNorthEast = 0;
            location25.MoveSouthEast = 0;

            locations.Add(location25);

            return locations;
        }
    }
}
